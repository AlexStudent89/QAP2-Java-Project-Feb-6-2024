
package Problem_02;

// TestMyRectangle.java

public class TestMyRectangle {
    /**
     * @param args
     */
    public static void main(String[] args) {
        // Test the MyRectangle class here
        MyPoint point1 = new MyPoint(6, 9);
        MyPoint point2 = new MyPoint(3, 5);
       
        @SuppressWarnings("unused")
        MyPoint insideMyPoint = new MyPoint(3, 4);


        MyRectangle rectangle1 = new MyRectangle(6, 9, 3, 5);
        @SuppressWarnings("unused")
        MyRectangle rectangle2 = new MyRectangle(point1, point2);


        System.out.println("Rectangle 1: " + rectangle1);
        System.out.println("Area of Rectangle 1: " + rectangle1.getArea());
        System.out.println("Perimeter of Rectangle 1: " + rectangle1.getPerimeter());

        
    }
}
