
package Problem_03;

// Money.java
public class Money {
    private long dollars;
    private long cents;

    public Money(double amount) {
        if (amount < 0) {
            System.out.println("Error: Negative amounts of money are not allowed.");
        } else {
            long allCents = Math.round(amount * 100);
            dollars = allCents / 100;
            cents = allCents % 100;
        }
    }

    public Money(Money otherObject) {
        this.dollars = otherObject.dollars;
        this.cents = otherObject.cents;
    }

    public Money add(Money otherAmount) {
        Money sum = new Money(0);
        sum.cents = this.cents + otherAmount.cents;
        long carryDollars = sum.cents / 100;
        sum.cents = sum.cents % 100;
        sum.dollars = this.dollars + otherAmount.dollars + carryDollars;
        return sum;
    }

    public Money subtract(Money otherAmount) {
        long thisAmountInCents = this.dollars * 100 + this.cents;
        long otherAmountInCents = otherAmount.dollars * 100 + otherAmount.cents;
        long differenceInCents = thisAmountInCents - otherAmountInCents;

        if (differenceInCents < 0) {
            System.out.println("Error: Negative result after subtraction.");
            return new Money(0);
        }

        Money result = new Money(0);
        result.dollars = differenceInCents / 100;
        result.cents = differenceInCents % 100;
        return result;
    }

    public int compareTo(Money otherObject) {
        long thisAmountInCents = this.dollars * 100 + this.cents;
        long otherAmountInCents = otherObject.dollars * 100 + otherObject.cents;

        if (thisAmountInCents < otherAmountInCents) {
            return -1;
        } else if (thisAmountInCents > otherAmountInCents) {
            return 1;
        } else {
            return 0;
        }
    }

    public boolean equals(Money otherObject) {
        return this.dollars == otherObject.dollars && this.cents == otherObject.cents;
    }

    @Override
    public String toString() {
        return String.format("$%d.%02d", dollars, cents);
    }
}
