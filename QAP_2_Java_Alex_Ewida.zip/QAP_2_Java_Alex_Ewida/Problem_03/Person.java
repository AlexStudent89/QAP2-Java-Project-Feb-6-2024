
package Problem_03;

// Person.java
public class Person {
    private String lastName;
    private String firstName;
    

    public Person(String lastName, String firstName, Address home) {
        this.lastName = lastName;
        this.firstName = firstName;
        
    }

    @Override
    public String toString() {
        return firstName + " " + lastName;
    }
}
