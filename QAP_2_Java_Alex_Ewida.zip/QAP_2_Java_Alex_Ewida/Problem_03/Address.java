
package Problem_03;

// Address.java
public class Address {
    @SuppressWarnings("unused")
    private String street;
    private String city;
    @SuppressWarnings("unused")
    private String state;
    @SuppressWarnings("unused")
    private String zip;

    public Address(String street, String city, String state, String zip) {
        // Implementation
    }

    @Override
    public String toString() {
        return city;
        // Implementation
    }
}
