// MyPoint.java

public class MyPoint {
    // the private instance variables to store the x and y coordinates
    private int x;
    private int y;

    // This will help initialize MyPoint with the given x and y coordinates
    public MyPoint(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // The getter method to retrieve the x coordinate
    public int getX() {
        return x;
    }

    // The setter method to set the x coordinate
    public void setX(int x) {
        this.x = x;
    }

    // The getter method to retrieve the y coordinate
    public int getY() {
        return y;
    }

    // The setter method to set the y coordinate
    public void setY(int y) {
        this.y = y;
    }

    // How to get the x and y coordinates as an array
    public int[] getXY() {
        return new int[]{x, y};
    }

    // How to set both x and y coordinates at once
    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // How to calculate the distance between two MyPoint objects
    public double distance(MyPoint p)
    {
        int xDiff = this.x-p.getX();
        int yDiff = this.y-p.getY();
        return Math.sqrt(xDiff*xDiff + yDiff*yDiff);
    }
   public double distance()
   {
    int xDiff = this.x-0;
    int yDiff = this.y-0;
    return Math.sqrt(xDiff*xDiff + yDiff*yDiff);
   }

}