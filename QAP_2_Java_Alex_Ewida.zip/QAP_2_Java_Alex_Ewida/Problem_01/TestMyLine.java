// TestMyLine.java


public class TestMyLine {
    public static void main(String[] args) {
        // To test my MyLine class here
        MyPoint point1 = new MyPoint(1, 2);
        MyPoint point2 = new MyPoint(4, 6);

        MyLine line1 = new MyLine(point1, point2);
        System.out.println(line1.toString());
        System.out.println("Length: " + line1.getLength());
        System.out.println("Gradient: " + line1.getGradient());

        
    }
}